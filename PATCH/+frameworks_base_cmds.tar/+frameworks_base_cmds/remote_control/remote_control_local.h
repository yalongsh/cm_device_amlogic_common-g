/** @file remote_control_local.h
 *  @par Copyright:
 *  - Copyright 2011 Amlogic Inc as unpublished work                             
 *  All Rights Reserved                                                                                                                              
 *  - The information contained herein is the confidential property            
 *  of Amlogic.  The use, copying, transfer or disclosure of such information
 *  is prohibited except by express written agreement with Amlogic Inc. 
 *  @author   tellen
 *  @version  1.0        
 *  @date     2011/06/07
 *  @par function description:
 *  - 1 remote control server, communication with local(framework)
 *  @warning This class may explode in your face.
 *  @note If you inherit anything from this class, you're doomed.
 */
 
#ifndef _REMOTE_CONTROL_LOCAL_H_
#define _REMOTE_CONTROL_LOCAL_H_

#ifdef __cplusplus
extern "C" {
#endif

#define MAX_LISTEN_NUM			10

void *rc_event_send(void *p);
void *rc_event_recv(void *p);
void *rc_sensor_listen(void *p);
void *rc_sensor_send(void *p);

extern void rc_stream_recv_msg(void);

#ifdef __cplusplus
}
#endif

#endif/*_REMOTE_CONTROL_LOCAL_H_*/

